package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

public class StopwatchActivity extends AppCompatActivity {
    //Number of seconds displayed on th stopwatch
    private int seconds = 0;
    //Is the stopWatch running?
    private boolean running;

    //Take the time
    private boolean takeP = false;
    //Vuelta
    private int nVuelta = 0;
    //cadena de vueltas
    private String sVuelta ="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stopwatch);
        if (savedInstanceState !=null){
            seconds = savedInstanceState.getInt("seconds");
            running = savedInstanceState.getBoolean("running");
            takeP = savedInstanceState.getBoolean("takep");
            nVuelta = savedInstanceState.getInt("nvuelta");
            sVuelta = savedInstanceState.getString("svuelta");
        }
        runTimer();
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("seconds", seconds);
        savedInstanceState.putBoolean("running", running);
        savedInstanceState.putBoolean("takep", takeP);
        savedInstanceState.putInt("nvuelta", nVuelta);
        savedInstanceState.putString("svuelta", sVuelta);
    }

    //Star the stopwatch running when the Start button is clicked
    public void onClickStart(View view){
        running = true;
    }

    public void onClickParcial(View view){
        running = true;
        takeP = true;
    }

    //Stop the stopwatch running when the Stop button is clicked
    public void onClickStop(View view){
        takeP = false;
        running = false;
    }

    //Reset the stopwatch when the Reset button is clicked
    public void onClickReset(View view){
        takeP = false;
        running = false;
        seconds = 0;
        sVuelta = "";
        nVuelta = 7;

    }

    //Sets the number of seconds on the timer
    private void runTimer(){
        final TextView timeView = (TextView) findViewById(R.id.time_view);
        TextView vueltasView = (TextView) findViewById(R.id.vueltas_view);
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds/3600;
                int minutes = (seconds%3600)/60;
                int secs = seconds%60;
                String time = String.format(Locale.getDefault(),
                        "%d:%02d:%02d", hours, minutes, secs);
                timeView.setText(time);
                if (running){
                    seconds++;
                }
                if (nVuelta==7){
                    nVuelta = 0;
                    vueltasView.setText("");
                }
                if (takeP && (nVuelta<5)){
                    nVuelta++;
                    sVuelta += nVuelta + " " + time + "\n";
                    vueltasView.setText(sVuelta);
                    takeP = false;
                }

                handler.postDelayed(this, 1000);
            }
        });

    }
}